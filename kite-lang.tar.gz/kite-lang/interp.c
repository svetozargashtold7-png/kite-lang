#include "kite.h"

#define MAX_STEPS 5000000LL

Interp *interp_new(void)  { return calloc(1, sizeof(Interp)); }
void    interp_free(Interp *ip) { free(ip); }

void kite_error(Interp *ip, int line, const char *fmt, ...) {
    ip->had_error = 1;
    char tmp[400]; va_list ap; va_start(ap,fmt); vsnprintf(tmp,sizeof(tmp),fmt,ap); va_end(ap);
    snprintf(ip->errbuf, sizeof(ip->errbuf), "line %d: %s", line, tmp);
}

/* ── Global interp pointer for builtins that call user functions ── */
static Interp *g_ip = NULL;

/* ══════════════════════════════════════════════════════════
   HELPERS
══════════════════════════════════════════════════════════ */
#define BUILTIN_ERR(msg) \
    do { if (g_ip) { kite_error(g_ip, 0, "%s", msg); } return val_nil(); } while(0)

static Value *list_push_val(Value *lst, Value *item) {
    if (lst->type != VT_LIST) { BUILTIN_ERR("push: expected list"); }
    KiteList *l = lst->list;
    if (l->len >= l->cap) {
        l->cap = l->cap ? l->cap*2 : 8;
        l->items = realloc(l->items, (size_t)l->cap * sizeof(Value*));
    }
    l->items[l->len++] = val_ref(item);
    return val_ref(lst);
}

static Value *call_fn(Interp *ip, Value *fn, Value **args, int nargs, int line);
Value *eval(Interp *ip, Node *n, Env *env);

static Value *eval_block(Interp *ip, NodeList *stmts, Env *env) {
    Value *last = val_nil();
    for (int i=0; i<stmts->len && !ip->had_error; i++) {
        val_unref(last);
        last = eval(ip, stmts->items[i], env);
        if (ip->has_return || ip->has_break || ip->has_next) break;
    }
    return last;
}

/* ══════════════════════════════════════════════════════════
   BUILT-IN FUNCTIONS
══════════════════════════════════════════════════════════ */

/* I/O */
static Value *bi_say(Value **args, int nargs) {
    for (int i=0;i<nargs;i++) {
        if (i) putchar(' ');
        val_print(args[i], stdout);
    }
    putchar('\n');
    return val_nil();
}
static Value *bi_input(Value **args, int nargs) {
    if (nargs >= 1) { char *s=val_tostr(args[0]); printf("%s",s); fflush(stdout); free(s); }
    char buf[4096]; buf[0]='\0';
    if (fgets(buf, (int)sizeof(buf), stdin)) {
        int n = (int)strlen(buf);
        if (n>0 && buf[n-1]=='\n') buf[n-1]='\0';
    }
    return val_str(buf);
}

/* Types */
static Value *bi_type(Value **args, int nargs) {
    if (nargs<1) return val_str("nil");
    switch (args[0]->type) {
        case VT_NIL:     return val_str("nil");
        case VT_BOOL:    return val_str("bool");
        case VT_NUM:     return val_str("num");
        case VT_STR:     return val_str("str");
        case VT_LIST:    return val_str("list");
        case VT_MAP:     return val_str("map");
        case VT_FN:      return val_str("fn");
        case VT_BUILTIN: return val_str("builtin");
    }
    return val_str("?");
}
static Value *bi_str_conv(Value **args, int nargs) {
    if (nargs<1) return val_str("");
    char *s = val_tostr(args[0]); Value *v = val_str(s); free(s); return v;
}
static Value *bi_num_conv(Value **args, int nargs) {
    if (nargs<1) BUILTIN_ERR("num: expected arg");
    if (args[0]->type==VT_NUM)  return val_ref(args[0]);
    if (args[0]->type==VT_BOOL) return val_num(args[0]->bval);
    if (args[0]->type==VT_STR)  return val_num(atof(args[0]->str));
    BUILTIN_ERR("num: cannot convert");
}

/* Collections */
static Value *bi_len(Value **args, int nargs) {
    if (nargs<1) BUILTIN_ERR("len: expected arg");
    if (args[0]->type==VT_STR)  return val_num((double)strlen(args[0]->str));
    if (args[0]->type==VT_LIST) return val_num((double)args[0]->list->len);
    if (args[0]->type==VT_MAP)  return val_num((double)args[0]->map->len);
    BUILTIN_ERR("len: unsupported type");
}
static Value *bi_push(Value **args, int nargs) {
    if (nargs<2) BUILTIN_ERR("push: expected (list, val)");
    return list_push_val(args[0], args[1]);
}
static Value *bi_pop(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_LIST) BUILTIN_ERR("pop: expected list");
    KiteList *l = args[0]->list;
    if (l->len==0) return val_nil();
    return l->items[--l->len]; /* hand off ref */
}
static Value *bi_keys(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_MAP) BUILTIN_ERR("keys: expected map");
    Value *res = val_list();
    KiteMap *m = args[0]->map;
    for (int i=0;i<m->len;i++) {
        Value *k = val_str(m->keys[i]);
        list_push_val(res, k); val_unref(k);
    }
    return res;
}
static Value *bi_vals(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_MAP) BUILTIN_ERR("vals: expected map");
    Value *res = val_list();
    KiteMap *m = args[0]->map;
    for (int i=0;i<m->len;i++) list_push_val(res, m->vals[i]);
    return res;
}
static Value *bi_has(Value **args, int nargs) {
    if (nargs<2) BUILTIN_ERR("has: expected 2 args");
    Value *col=args[0], *key=args[1];
    if (col->type==VT_LIST) {
        for (int i=0;i<col->list->len;i++) if (val_eq(col->list->items[i],key)) return val_bool(1);
        return val_bool(0);
    }
    if (col->type==VT_MAP) {
        if (key->type!=VT_STR) BUILTIN_ERR("has: map key must be str");
        for (int i=0;i<col->map->len;i++) if (strcmp(col->map->keys[i],key->str)==0) return val_bool(1);
        return val_bool(0);
    }
    if (col->type==VT_STR && key->type==VT_STR) return val_bool(strstr(col->str,key->str)!=NULL);
    BUILTIN_ERR("has: unsupported types");
}
static Value *bi_range(Value **args, int nargs) {
    double start=0,end_=0,step=1;
    if      (nargs==1) { end_=args[0]->num; }
    else if (nargs==2) { start=args[0]->num; end_=args[1]->num; }
    else if (nargs>=3) { start=args[0]->num; end_=args[1]->num; step=args[2]->num; }
    if (step==0) BUILTIN_ERR("range: step cannot be 0");
    Value *res = val_list();
    if (step>0) { for (double i=start;i<end_;i+=step) { Value *v=val_num(i); list_push_val(res,v); val_unref(v); } }
    else        { for (double i=start;i>end_;i+=step) { Value *v=val_num(i); list_push_val(res,v); val_unref(v); } }
    return res;
}
static Value *bi_slice(Value **args, int nargs) {
    if (nargs<1) BUILTIN_ERR("slice: expected args");
    Value *v=args[0];
    int start = nargs>=2 ? (int)args[1]->num : 0;
    int end_;
    if (v->type==VT_LIST) {
        int ln=v->list->len;
        if (start<0) { start=ln+start; }
        if (start<0) { start=0; }
        end_ = nargs>=3 ? (int)args[2]->num : ln;
        if (end_<0)  { end_=ln+end_; }
        if (end_>ln) { end_=ln; }
        Value *res=val_list();
        for (int i=start;i<end_;i++) list_push_val(res, v->list->items[i]);
        return res;
    }
    if (v->type==VT_STR) {
        int ln=(int)strlen(v->str);
        if (start<0) { start=ln+start; }
        if (start<0) { start=0; }
        end_ = nargs>=3 ? (int)args[2]->num : ln;
        if (end_<0)  { end_=ln+end_; }
        if (end_>ln) { end_=ln; }
        if (end_<=start) return val_str("");
        char *buf=malloc((size_t)(end_-start)+1);
        memcpy(buf, v->str+start, (size_t)(end_-start));
        buf[end_-start]='\0';
        Value *res=val_str(buf); free(buf); return res;
    }
    BUILTIN_ERR("slice: expected list or str");
}
static Value *bi_reverse(Value **args, int nargs) {
    if (nargs<1) BUILTIN_ERR("reverse: expected arg");
    if (args[0]->type==VT_LIST) {
        Value *res=val_list(); KiteList *l=args[0]->list;
        for (int i=l->len-1;i>=0;i--) list_push_val(res,l->items[i]);
        return res;
    }
    if (args[0]->type==VT_STR) {
        int ln=(int)strlen(args[0]->str);
        char *buf=malloc((size_t)ln+1);
        for (int i=0;i<ln;i++) buf[i]=args[0]->str[ln-1-i];
        buf[ln]='\0'; Value *v=val_str(buf); free(buf); return v;
    }
    BUILTIN_ERR("reverse: expected list or str");
}
static Value *bi_concat(Value **args, int nargs) {
    if (nargs<2||args[0]->type!=VT_LIST||args[1]->type!=VT_LIST)
        BUILTIN_ERR("concat: expected 2 lists");
    Value *res=val_list();
    KiteList *a=args[0]->list, *b=args[1]->list;
    for (int i=0;i<a->len;i++) list_push_val(res,a->items[i]);
    for (int i=0;i<b->len;i++) list_push_val(res,b->items[i]);
    return res;
}

/* Math */
static Value *bi_floor(Value **a, int n) { if(n<1)BUILTIN_ERR("floor: need num"); return val_num(floor(a[0]->num)); }
static Value *bi_ceil (Value **a, int n) { if(n<1)BUILTIN_ERR("ceil: need num");  return val_num(ceil (a[0]->num)); }
static Value *bi_round(Value **a, int n) { if(n<1)BUILTIN_ERR("round: need num"); return val_num(round(a[0]->num)); }
static Value *bi_sqrt (Value **a, int n) { if(n<1)BUILTIN_ERR("sqrt: need num");  return val_num(sqrt (a[0]->num)); }
static Value *bi_abs  (Value **a, int n) { if(n<1)BUILTIN_ERR("abs: need num");   return val_num(fabs (a[0]->num)); }
static Value *bi_sin  (Value **a, int n) { if(n<1)BUILTIN_ERR("sin: need num");   return val_num(sin  (a[0]->num)); }
static Value *bi_cos  (Value **a, int n) { if(n<1)BUILTIN_ERR("cos: need num");   return val_num(cos  (a[0]->num)); }
static Value *bi_log  (Value **a, int n) { if(n<1)BUILTIN_ERR("log: need num");   return val_num(log  (a[0]->num)); }

static Value *bi_min(Value **args, int nargs) {
    if (nargs==1 && args[0]->type==VT_LIST) {
        KiteList *l=args[0]->list; if(l->len==0) return val_nil();
        Value *m=l->items[0];
        for(int i=1;i<l->len;i++) if(l->items[i]->num < m->num) m=l->items[i];
        return val_ref(m);
    }
    if (nargs<1) BUILTIN_ERR("min: expected args");
    Value *m=args[0]; for(int i=1;i<nargs;i++) if(args[i]->num<m->num) m=args[i];
    return val_ref(m);
}
static Value *bi_max(Value **args, int nargs) {
    if (nargs==1 && args[0]->type==VT_LIST) {
        KiteList *l=args[0]->list; if(l->len==0) return val_nil();
        Value *m=l->items[0];
        for(int i=1;i<l->len;i++) if(l->items[i]->num > m->num) m=l->items[i];
        return val_ref(m);
    }
    if (nargs<1) BUILTIN_ERR("max: expected args");
    Value *m=args[0]; for(int i=1;i<nargs;i++) if(args[i]->num>m->num) m=args[i];
    return val_ref(m);
}

/* Strings */
static Value *bi_split(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_STR) BUILTIN_ERR("split: expected str");
    const char *sep = (nargs>=2&&args[1]->type==VT_STR) ? args[1]->str : " ";
    Value *res = val_list();
    if (strlen(sep)==0) {
        char ch[2]={0,0};
        for (const char *p=args[0]->str; *p; p++) {
            ch[0]=*p; Value *v=val_str(ch); list_push_val(res,v); val_unref(v);
        }
    } else {
        char *copy=strdup(args[0]->str), *tok=strtok(copy,sep);
        while(tok) { Value *v=val_str(tok); list_push_val(res,v); val_unref(v); tok=strtok(NULL,sep); }
        free(copy);
    }
    return res;
}
static Value *bi_join(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_LIST) BUILTIN_ERR("join: expected list");
    const char *sep = (nargs>=2&&args[1]->type==VT_STR) ? args[1]->str : "";
    KiteList *l=args[0]->list;
    /* compute total length */
    size_t total=0;
    for (int i=0;i<l->len;i++) { char *s=val_tostr(l->items[i]); total+=strlen(s)+strlen(sep); free(s); }
    char *buf=calloc(1,total+1);
    for (int i=0;i<l->len;i++) {
        if (i) strcat(buf,sep);
        char *s=val_tostr(l->items[i]); strcat(buf,s); free(s);
    }
    Value *v=val_str(buf); free(buf); return v;
}
static Value *bi_upcase(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_STR) BUILTIN_ERR("upcase: expected str");
    char *s=strdup(args[0]->str);
    for (int i=0;s[i];i++) s[i]=(char)toupper((unsigned char)s[i]);
    Value *v=val_str(s); free(s); return v;
}
static Value *bi_downcase(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_STR) BUILTIN_ERR("downcase: expected str");
    char *s=strdup(args[0]->str);
    for (int i=0;s[i];i++) s[i]=(char)tolower((unsigned char)s[i]);
    Value *v=val_str(s); free(s); return v;
}
static Value *bi_trim(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_STR) BUILTIN_ERR("trim: expected str");
    const char *s=args[0]->str;
    while (*s==' '||*s=='\t'||*s=='\n'||*s=='\r') s++;
    int ln=(int)strlen(s);
    while (ln>0 && (s[ln-1]==' '||s[ln-1]=='\t'||s[ln-1]=='\n'||s[ln-1]=='\r')) ln--;
    char *buf=malloc((size_t)ln+1); memcpy(buf,s,(size_t)ln); buf[ln]='\0';
    Value *v=val_str(buf); free(buf); return v;
}
static Value *bi_index_of(Value **args, int nargs) {
    if (nargs<2) BUILTIN_ERR("index_of: expected 2 args");
    if (args[0]->type==VT_STR&&args[1]->type==VT_STR) {
        char *p=strstr(args[0]->str,args[1]->str);
        return p ? val_num((double)(p-args[0]->str)) : val_num(-1);
    }
    if (args[0]->type==VT_LIST) {
        for (int i=0;i<args[0]->list->len;i++) if(val_eq(args[0]->list->items[i],args[1])) return val_num((double)i);
        return val_num(-1);
    }
    BUILTIN_ERR("index_of: unsupported type");
}
static Value *bi_replace(Value **args, int nargs) {
    if (nargs<3||args[0]->type!=VT_STR||args[1]->type!=VT_STR||args[2]->type!=VT_STR)
        BUILTIN_ERR("replace: expected (str, from, to)");
    const char *src=args[0]->str, *from=args[1]->str, *to=args[2]->str;
    int flen=(int)strlen(from); if(flen==0) return val_ref(args[0]);
    int tlen=(int)strlen(to);
    size_t cap=(strlen(src)+1)*(size_t)(tlen/flen+2)+2;
    char *buf=malloc(cap); const char *p=src; char *q=buf;
    while (*p) {
        if (strncmp(p,from,(size_t)flen)==0) { memcpy(q,to,(size_t)tlen); q+=tlen; p+=flen; }
        else *q++=*p++;
    }
    *q='\0'; Value *v=val_str(buf); free(buf); return v;
}

/* HOF helpers — call a user fn with 1 or 2 args */
static Value *call_user(Value *fn, Value *a, Value *b) {
    if (!g_ip) return val_nil();
    if (fn->type==VT_BUILTIN) {
        if (b) { Value *args[2]={a,b}; return fn->builtin.fn(args,2); }
        else   { Value *args[1]={a};   return fn->builtin.fn(args,1); }
    }
    if (fn->type!=VT_FN) return val_nil();
    KiteFn *kf=fn->fn;
    Env *fenv=env_new(kf->closure);
    if (kf->nparams>=1) env_def(fenv,kf->params[0],a);
    if (b && kf->nparams>=2) env_def(fenv,kf->params[1],b);
    Value *last=eval(g_ip,kf->body,fenv);
    env_unref(fenv);
    if (g_ip->has_return) {
        val_unref(last);
        Value *rv=g_ip->retval ? g_ip->retval : val_nil();
        g_ip->has_return=0; g_ip->retval=NULL;
        return rv;
    }
    return last;
}

static Value *bi_map_fn(Value **args, int nargs) {
    if (nargs<2||args[0]->type!=VT_LIST) BUILTIN_ERR("map: expected (list, fn)");
    Value *res=val_list(); KiteList *l=args[0]->list; Value *fn=args[1];
    for (int i=0;i<l->len;i++) {
        Value *v=call_user(fn,l->items[i],NULL);
        if (!v) v=val_nil();
        list_push_val(res,v); val_unref(v);
    }
    return res;
}
static Value *bi_filter_fn(Value **args, int nargs) {
    if (nargs<2||args[0]->type!=VT_LIST) BUILTIN_ERR("filter: expected (list, fn)");
    Value *res=val_list(); KiteList *l=args[0]->list; Value *fn=args[1];
    for (int i=0;i<l->len;i++) {
        Value *cond=call_user(fn,l->items[i],NULL);
        if (!cond) cond=val_nil();
        if (val_truthy(cond)) list_push_val(res,l->items[i]);
        val_unref(cond);
    }
    return res;
}
static Value *bi_reduce_fn(Value **args, int nargs) {
    if (nargs<2||args[0]->type!=VT_LIST) BUILTIN_ERR("reduce: expected (list, fn [, init])");
    KiteList *l=args[0]->list; Value *fn=args[1];
    Value *acc;
    int start;
    if (nargs>=3) { acc=val_ref(args[2]); start=0; }
    else if (l->len>0) { acc=val_ref(l->items[0]); start=1; }
    else return val_nil();
    for (int i=start;i<l->len;i++) {
        Value *nv=call_user(fn,acc,l->items[i]);
        val_unref(acc); acc=nv ? nv : val_nil();
    }
    return acc;
}
static Value *bi_sort_fn(Value **args, int nargs) {
    if (nargs<1||args[0]->type!=VT_LIST) BUILTIN_ERR("sort: expected list");
    Value *fn = nargs>=2 ? args[1] : NULL;
    KiteList *l=args[0]->list;
    Value *res=val_list();
    for (int i=0;i<l->len;i++) list_push_val(res,l->items[i]);
    /* insertion sort */
    KiteList *rl=res->list;
    for (int i=1;i<rl->len;i++) {
        Value *key=rl->items[i]; int j=i-1;
        while (j>=0) {
            int gt=0;
            if (fn) {
                Value *r=call_user(fn,rl->items[j],key);
                if (r) { gt=(r->type==VT_NUM) ? r->num>0 : val_truthy(r); val_unref(r); }
            } else {
                Value *a=rl->items[j];
                if      (a->type==VT_NUM && key->type==VT_NUM) gt=a->num>key->num;
                else if (a->type==VT_STR && key->type==VT_STR) gt=strcmp(a->str,key->str)>0;
            }
            if (!gt) break;
            rl->items[j+1]=rl->items[j]; j--;
        }
        rl->items[j+1]=key;
    }
    return res;
}

void setup_builtins(Env *env) {
    #define REG(nm,fn) do { Value *v=val_builtin(fn,nm); env_def(env,nm,v); val_unref(v); } while(0)
    REG("say",      bi_say);
    REG("input",    bi_input);
    REG("type",     bi_type);
    REG("str",      bi_str_conv);
    REG("num",      bi_num_conv);
    REG("len",      bi_len);
    REG("push",     bi_push);
    REG("pop",      bi_pop);
    REG("keys",     bi_keys);
    REG("vals",     bi_vals);
    REG("has",      bi_has);
    REG("range",    bi_range);
    REG("slice",    bi_slice);
    REG("reverse",  bi_reverse);
    REG("concat",   bi_concat);
    REG("sort",     bi_sort_fn);
    REG("map",      bi_map_fn);
    REG("filter",   bi_filter_fn);
    REG("reduce",   bi_reduce_fn);
    REG("floor",    bi_floor);
    REG("ceil",     bi_ceil);
    REG("round",    bi_round);
    REG("sqrt",     bi_sqrt);
    REG("abs",      bi_abs);
    REG("sin",      bi_sin);
    REG("cos",      bi_cos);
    REG("log",      bi_log);
    REG("min",      bi_min);
    REG("max",      bi_max);
    REG("split",    bi_split);
    REG("join",     bi_join);
    REG("upcase",   bi_upcase);
    REG("downcase", bi_downcase);
    REG("trim",     bi_trim);
    REG("index_of", bi_index_of);
    REG("replace",  bi_replace);
    #undef REG
    Value *pi=val_num(3.14159265358979323846); env_def(env,"PI",pi);  val_unref(pi);
    Value *tau=val_num(6.28318530717958647692); env_def(env,"TAU",tau); val_unref(tau);
}

/* ══════════════════════════════════════════════════════════
   EVALUATOR
══════════════════════════════════════════════════════════ */
static Value *call_fn(Interp *ip, Value *fn, Value **args, int nargs, int line) {
    g_ip = ip;
    if (!fn) { kite_error(ip,line,"nil is not callable"); return val_nil(); }
    if (fn->type==VT_BUILTIN) return fn->builtin.fn(args,nargs);
    if (fn->type==VT_FN) {
        KiteFn *kf=fn->fn;
        Env *fenv=env_new(kf->closure);
        for (int i=0;i<kf->nparams;i++) {
            Value *a = i<nargs ? val_ref(args[i]) : val_nil();
            env_def(fenv,kf->params[i],a); val_unref(a);
        }
        Value *last=eval(ip,kf->body,fenv);
        env_unref(fenv);
        if (ip->has_return) {
            val_unref(last);
            Value *rv=ip->retval ? ip->retval : val_nil();
            ip->has_return=0; ip->retval=NULL;
            return rv;
        }
        return last; /* lambda implicit return */
    }
    kite_error(ip,line,"not callable");
    return val_nil();
}

Value *eval(Interp *ip, Node *n, Env *env) {
    if (!n || ip->had_error) return val_nil();
    if (++ip->steps > MAX_STEPS) {
        kite_error(ip,n->line,"execution limit reached (infinite loop?)");
        return val_nil();
    }

    switch (n->kind) {

    case ND_NIL:  return val_nil();
    case ND_BOOL: return val_bool(n->bval);
    case ND_NUM:  return val_num(n->num);
    case ND_STR:  return val_str(n->str);

    case ND_FMTSTR: {
        /* build string by evaluating each part and concatenating */
        char *result = strdup(""); size_t rlen=0;
        for (int i=0; i<n->fmtstr.len && !ip->had_error; i++) {
            Value *v  = eval(ip, n->fmtstr.items[i], env);
            char  *part = val_tostr(v); val_unref(v);
            size_t plen = strlen(part);
            result = realloc(result, rlen+plen+1);
            memcpy(result+rlen, part, plen+1);
            rlen += plen; free(part);
        }
        Value *res=val_str(result); free(result); return res;
    }

    case ND_IDENT: {
        Value *v=env_get(env,n->str);
        if (!v) { kite_error(ip,n->line,"undefined variable '%s'",n->str); return val_nil(); }
        return val_ref(v);
    }

    case ND_SET: {
        Value *v=eval(ip,n->set.val,env);
        env_def(env,n->set.name,v); val_unref(v);
        return val_nil();
    }

    case ND_ASSIGN: {
        Value *rhs=eval(ip,n->assign.val,env);
        const char *op=n->assign.op;
        Node *tgt=n->assign.target;

        if (tgt->kind==ND_IDENT) {
            Value *newval=rhs;
            if (strcmp(op,"=")!=0) {
                Value *cur=env_get(env,tgt->str);
                if (!cur) { kite_error(ip,n->line,"undefined '%s'",tgt->str); val_unref(rhs); return val_nil(); }
                if      (strcmp(op,"+=")==0) {
                    if (cur->type==VT_NUM) newval=val_num(cur->num+rhs->num);
                    else if (cur->type==VT_STR) {
                        char *s=malloc(strlen(cur->str)+strlen(rhs->str)+1);
                        strcpy(s,cur->str); strcat(s,rhs->str);
                        newval=val_str(s); free(s);
                    }
                }
                else if (strcmp(op,"-=")==0) newval=val_num(cur->num-rhs->num);
                else if (strcmp(op,"*=")==0) newval=val_num(cur->num*rhs->num);
                else if (strcmp(op,"/=")==0) {
                    if (rhs->num==0) { kite_error(ip,n->line,"division by zero"); val_unref(rhs); return val_nil(); }
                    newval=val_num(cur->num/rhs->num);
                }
                val_unref(rhs);
            }
            if (!env_set(env,tgt->str,newval)) env_def(env,tgt->str,newval);
            Value *ret=val_ref(newval); val_unref(newval); return ret;
        }

        if (tgt->kind==ND_INDEX) {
            Value *obj=eval(ip,tgt->idx.obj,env);
            Value *idx=eval(ip,tgt->idx.idx,env);
            if (obj->type==VT_LIST && idx->type==VT_NUM) {
                int ii=(int)idx->num;
                if (ii<0) ii=obj->list->len+ii;
                KiteList *l=obj->list;
                if (ii>=0 && ii<l->len) { val_unref(l->items[ii]); l->items[ii]=val_ref(rhs); }
                else if (ii==l->len) list_push_val(obj,rhs);
                else kite_error(ip,n->line,"list index out of range");
            } else if (obj->type==VT_MAP) {
                char *key=val_tostr(idx); KiteMap *m=obj->map;
                int found=0;
                for (int i=0;i<m->len;i++) {
                    if (strcmp(m->keys[i],key)==0) { val_unref(m->vals[i]); m->vals[i]=val_ref(rhs); found=1; break; }
                }
                if (!found) {
                    if (m->len>=m->cap) { m->cap=m->cap?m->cap*2:8; m->keys=realloc(m->keys,(size_t)m->cap*sizeof(char*)); m->vals=realloc(m->vals,(size_t)m->cap*sizeof(Value*)); }
                    m->keys[m->len]=strdup(key); m->vals[m->len]=val_ref(rhs); m->len++;
                }
                free(key);
            }
            val_unref(obj); val_unref(idx); val_unref(rhs);
            return val_nil();
        }
        kite_error(ip,n->line,"invalid assignment target");
        val_unref(rhs); return val_nil();
    }

    case ND_BINOP: {
        const char *op=n->binop.op;
        /* short-circuit */
        if (strcmp(op,"and")==0) {
            Value *l=eval(ip,n->binop.left,env);
            if (!val_truthy(l)) return l;
            val_unref(l); return eval(ip,n->binop.right,env);
        }
        if (strcmp(op,"or")==0) {
            Value *l=eval(ip,n->binop.left,env);
            if (val_truthy(l)) return l;
            val_unref(l); return eval(ip,n->binop.right,env);
        }
        Value *l=eval(ip,n->binop.left,env);
        Value *r=eval(ip,n->binop.right,env);
        Value *res=NULL;

        if      (strcmp(op,"+")==0) {
            if (l->type==VT_NUM && r->type==VT_NUM) res=val_num(l->num+r->num);
            else if (l->type==VT_STR || r->type==VT_STR) {
                char *ls=val_tostr(l), *rs=val_tostr(r);
                char *s=malloc(strlen(ls)+strlen(rs)+1); strcpy(s,ls); strcat(s,rs);
                res=val_str(s); free(s); free(ls); free(rs);
            } else if (l->type==VT_LIST && r->type==VT_LIST) {
                Value *tmp[2]={l,r}; res=bi_concat(tmp,2);
            } else kite_error(ip,n->line,"'+' unsupported types");
        }
        else if (strcmp(op,"-")==0) {
            if (l->type==VT_NUM && r->type==VT_NUM) res=val_num(l->num-r->num);
            else kite_error(ip,n->line,"'-' needs numbers");
        }
        else if (strcmp(op,"*")==0) {
            if (l->type==VT_NUM && r->type==VT_NUM) res=val_num(l->num*r->num);
            else if (l->type==VT_STR && r->type==VT_NUM) {
                int times=(int)r->num;
                size_t slen=strlen(l->str);
                char *s=calloc(1, slen*(size_t)times+1);
                for (int i=0;i<times;i++) strcat(s,l->str);
                res=val_str(s); free(s);
            } else kite_error(ip,n->line,"'*' unsupported types");
        }
        else if (strcmp(op,"/")==0) {
            if (r->num==0.0) { kite_error(ip,n->line,"division by zero"); res=val_nil(); }
            else res=val_num(l->num/r->num);
        }
        else if (strcmp(op,"%")==0)  res=val_num(fmod(l->num,r->num));
        else if (strcmp(op,"^")==0)  res=val_num(pow(l->num,r->num));
        else if (strcmp(op,"..")==0) {
            char *ls=val_tostr(l), *rs=val_tostr(r);
            char *s=malloc(strlen(ls)+strlen(rs)+1); strcpy(s,ls); strcat(s,rs);
            res=val_str(s); free(s); free(ls); free(rs);
        }
        else if (strcmp(op,"==")==0) res=val_bool(val_eq(l,r));
        else if (strcmp(op,"!=")==0) res=val_bool(!val_eq(l,r));
        else if (strcmp(op,"<")==0) {
            if (l->type==VT_NUM && r->type==VT_NUM)   res=val_bool(l->num<r->num);
            else if (l->type==VT_STR && r->type==VT_STR) res=val_bool(strcmp(l->str,r->str)<0);
            else kite_error(ip,n->line,"'<' needs comparable types");
        }
        else if (strcmp(op,">")==0) {
            if (l->type==VT_NUM && r->type==VT_NUM)   res=val_bool(l->num>r->num);
            else if (l->type==VT_STR && r->type==VT_STR) res=val_bool(strcmp(l->str,r->str)>0);
            else kite_error(ip,n->line,"'>' needs comparable types");
        }
        else if (strcmp(op,"<=")==0) res=val_bool(l->num<=r->num);
        else if (strcmp(op,">=")==0) res=val_bool(l->num>=r->num);
        else kite_error(ip,n->line,"unknown operator '%s'",op);

        val_unref(l); val_unref(r);
        return res ? res : val_nil();
    }

    case ND_UNOP: {
        Value *v=eval(ip,n->unop.expr,env); Value *res=NULL;
        if (strcmp(n->unop.op,"-")==0) {
            if (v->type==VT_NUM) res=val_num(-v->num);
            else kite_error(ip,n->line,"unary '-' needs number");
        } else res=val_bool(!val_truthy(v));
        val_unref(v); return res ? res : val_nil();
    }

    case ND_CALL: {
        g_ip=ip;
        Value *callee=eval(ip,n->call.callee,env);
        int na=n->call.args.len;
        Value **args=malloc((size_t)(na ? na : 1)*sizeof(Value*));
        for (int i=0;i<na;i++) args[i]=eval(ip,n->call.args.items[i],env);
        Value *res=call_fn(ip,callee,args,na,n->line);
        for (int i=0;i<na;i++) val_unref(args[i]);
        free(args); val_unref(callee);
        return res ? res : val_nil();
    }

    case ND_INDEX: {
        Value *obj=eval(ip,n->idx.obj,env);
        Value *idx=eval(ip,n->idx.idx,env);
        Value *res=NULL;
        if (obj->type==VT_LIST && idx->type==VT_NUM) {
            int i=(int)idx->num; if(i<0) i=obj->list->len+i;
            res=(i>=0&&i<obj->list->len) ? val_ref(obj->list->items[i]) : val_nil();
        } else if (obj->type==VT_STR && idx->type==VT_NUM) {
            int i=(int)idx->num; int ln=(int)strlen(obj->str); if(i<0) i=ln+i;
            if (i>=0&&i<ln) { char ch[2]={obj->str[i],'\0'}; res=val_str(ch); }
            else res=val_nil();
        } else if (obj->type==VT_MAP) {
            char *key=val_tostr(idx); KiteMap *m=obj->map;
            for (int i=0;i<m->len;i++) if(strcmp(m->keys[i],key)==0){res=val_ref(m->vals[i]);break;}
            free(key); if(!res) res=val_nil();
        } else { kite_error(ip,n->line,"cannot index type '%s'",
                    obj->type==VT_NUM?"num":obj->type==VT_BOOL?"bool":"other"); }
        val_unref(obj); val_unref(idx);
        return res ? res : val_nil();
    }

    case ND_PROP: {
        Value *obj=eval(ip,n->prop.obj,env); Value *res=NULL;
        if (obj->type==VT_MAP) {
            KiteMap *m=obj->map;
            for (int i=0;i<m->len;i++) if(strcmp(m->keys[i],n->prop.prop)==0){res=val_ref(m->vals[i]);break;}
        }
        val_unref(obj);
        return res ? res : val_nil();
    }

    case ND_LIST: {
        Value *res=val_list();
        for (int i=0;i<n->list.len;i++) {
            Value *item=eval(ip,n->list.items[i],env);
            list_push_val(res,item); val_unref(item);
        }
        return res;
    }

    case ND_MAP: {
        Value *res=val_map(); KiteMap *m=res->map;
        for (int i=0;i<n->map.len;i++) {
            Value *v=eval(ip,n->map.pairs[i].val,env);
            if (m->len>=m->cap) { m->cap=m->cap?m->cap*2:8; m->keys=realloc(m->keys,(size_t)m->cap*sizeof(char*)); m->vals=realloc(m->vals,(size_t)m->cap*sizeof(Value*)); }
            m->keys[m->len]=strdup(n->map.pairs[i].key); m->vals[m->len]=v; m->len++;
        }
        return res;
    }

    case ND_LAMBDA: {
        KiteFn *kf=calloc(1,sizeof(KiteFn));
        kf->nparams=n->lambda.nparams;
        kf->params=malloc((size_t)(kf->nparams ? kf->nparams : 1)*sizeof(char*));
        for (int i=0;i<kf->nparams;i++) kf->params[i]=strdup(n->lambda.params[i]);
        kf->body=n->lambda.body; kf->closure=env; env_ref(env); kf->refs=0;
        return val_fn(kf);
    }

    case ND_DEF: {
        KiteFn *kf=calloc(1,sizeof(KiteFn));
        kf->name=strdup(n->def.name); kf->nparams=n->def.nparams;
        kf->params=malloc((size_t)(kf->nparams ? kf->nparams : 1)*sizeof(char*));
        for (int i=0;i<kf->nparams;i++) kf->params[i]=strdup(n->def.params[i]);
        kf->body=n->def.body; kf->closure=env; env_ref(env); kf->refs=0;
        Value *v=val_fn(kf); env_def(env,n->def.name,v); val_unref(v);
        return val_nil();
    }

    case ND_WHEN: {
        for (int i=0;i<n->when.nbranch;i++) {
            int taken=0;
            if (!n->when.conds[i]) { taken=1; }
            else { Value *cv=eval(ip,n->when.conds[i],env); taken=val_truthy(cv); val_unref(cv); }
            if (taken) {
                Env *be=env_new(env);
                eval_block(ip,&n->when.bodies[i]->block,be);
                env_unref(be); return val_nil();
            }
        }
        return val_nil();
    }

    case ND_LOOP_WHILE: {
        long long guard=0;
        while (1) {
            Value *cond=eval(ip,n->loop_while.cond,env);
            int t=val_truthy(cond); val_unref(cond);
            if (!t||ip->had_error) break;
            if (++guard>2000000) { kite_error(ip,n->line,"loop limit reached"); break; }
            Env *le=env_new(env); eval_block(ip,&n->loop_while.body->block,le); env_unref(le);
            if (ip->has_return) break;
            if (ip->has_break) { ip->has_break=0; break; }
            if (ip->has_next)  { ip->has_next=0;  continue; }
        }
        return val_nil();
    }

    case ND_LOOP_FOR: {
        Value *iter=eval(ip,n->loop_for.iter,env);
        if (iter->type==VT_LIST) {
            KiteList *l=iter->list;
            for (int i=0;i<l->len&&!ip->had_error;i++) {
                Env *le=env_new(env); env_def(le,n->loop_for.var,l->items[i]);
                eval_block(ip,&n->loop_for.body->block,le); env_unref(le);
                if (ip->has_return) break;
                if (ip->has_break) { ip->has_break=0; break; }
                if (ip->has_next)  { ip->has_next=0;  continue; }
            }
        } else if (iter->type==VT_STR) {
            const char *s=iter->str;
            for (int i=0;s[i]&&!ip->had_error;i++) {
                char ch[2]={s[i],'\0'}; Value *cv=val_str(ch);
                Env *le=env_new(env); env_def(le,n->loop_for.var,cv); val_unref(cv);
                eval_block(ip,&n->loop_for.body->block,le); env_unref(le);
                if (ip->has_return||ip->has_break) { ip->has_break=0; break; }
                if (ip->has_next) { ip->has_next=0; continue; }
            }
        } else kite_error(ip,n->line,"for: can only iterate list or str");
        val_unref(iter); return val_nil();
    }

    case ND_GIVE: {
        Value *v=n->child ? eval(ip,n->child,env) : val_nil();
        ip->has_return=1;
        if (ip->retval) val_unref(ip->retval);
        ip->retval=v; return val_nil();
    }

    case ND_BREAK: ip->has_break=1; return val_nil();
    case ND_NEXT:  ip->has_next=1;  return val_nil();

    case ND_EXPR_STMT: {
        Value *v=eval(ip,n->child,env); val_unref(v); return val_nil();
    }

    case ND_BLOCK:
    case ND_PROGRAM:
        return eval_block(ip,&n->block,env);

    default:
        kite_error(ip,n->line,"unknown node kind %d",n->kind);
        return val_nil();
    }
}
